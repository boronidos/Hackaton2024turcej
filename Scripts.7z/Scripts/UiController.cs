using UnityEngine;
using UnityEngine.SceneManagement;

public class UiController : MonoBehaviour
{
    public void ReloadScene()
    {
        Time.timeScale = 1.0f;
        SceneManager.LoadScene("TestScene");
    }
}
