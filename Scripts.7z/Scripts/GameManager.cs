using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using TMPro;
using UnityEngine.Rendering.Universal;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class GameManager : MonoBehaviour {
    public static GameManager instance { private set; get; }

    float speed;
    public float superSpeed;
    public float normalSpeed;
    public Tilemap tilemapBlocks;
    public Tilemap tilemap;
    public Tilemap tilemapStaticBlocks;
    public Tilemap tilemapGhost;
    public int score = 0;
    public int highScore;
    bool isDead = false;
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI highScoreText;
    public TextMeshProUGUI nextGhostText;
    public GameObject GameOverText;
    public GameObject RestartButton;

    public int roundsTillGhostSpawn;
    public int roundsTillGhostShow;

    public float speedIncrease;

    float timeSinceBlockSpawn;

    float timeSinceLastRound;

    float speedMultiplier = 1;

    public Tile ghostTile;

    bool placingGhost;
    bool spawnedGhost;

    bool firstGhost = true;

    public bool playTutorial;

    [SerializeField]
    public List<Block> blockList;

    bool[,] ghostSnapshot;

    public List<Tile> types;

    //public int ghostX;
    bool playedReverseDialogue;

    public Block ghost;
    //public int ghostRotations;

    private int currentBlock;
    private Vector3Int pivotPoint = Vector3Int.zero;

    int turn;

    Tile[,] beforeTab1 = new Tile[10, 20];
    Tile[,] beforeTab2 = new Tile[10, 20];
    Tile[,] beforeTab3 = new Tile[10, 20];
    Tile[,] beforeTab4 = new Tile[10, 20];
    Tile[,] beforeTab5 = new Tile[10, 20];
    Tile[,] beforeTab6 = new Tile[10, 20];
    Tile[,] beforeTab7 = new Tile[10, 20];
    Tile[,] beforeTab8 = new Tile[10, 20];
    Tile[,] beforeTab9 = new Tile[10, 20];
    Tile[,] beforeTab10 = new Tile[10, 20];

    public Volume volume;
    Bloom bloom;


    void Start() {
        LoadPrefs();

        if (highScore > 0) playTutorial = false;
        else playTutorial = true;


        if (playTutorial)
        {
            TutorialScript.instance.StartDialogue(0, 2);
        }

        ghostSnapshot = new bool[40, 40];

        roundsTillGhostShow = 4;
        speed = normalSpeed * speedMultiplier;
        currentBlock = Random.Range(0, blockList.Count);
        SpawnBlock(blockList[currentBlock], 0);
        StartCoroutine(UpdateTilemap(blockList[currentBlock].type, speed));

        SoundManager.instance.mainSource.clip = SoundManager.instance.playMusic;
        SoundManager.instance.mainSource.Play();
    }

    void Update() {

        if (volume.profile.TryGet<Bloom>(out bloom)) {
            if (bloom.intensity.value > 3) bloom.intensity.value -= Time.unscaledDeltaTime * 300;
        }

        speedMultiplier += Time.deltaTime * speedIncrease;

        if (isDead)
        {
            return;
        }

        if (score >= 800 && !playedReverseDialogue && playTutorial)
        {
            playedReverseDialogue = true;
            TutorialScript.instance.StartDialogue(4, 2);
        }

        scoreText.text = "Score: " + score.ToString();
        highScoreText.text = "High Score: " + highScore.ToString();
        nextGhostText.text = (Mathf.Clamp(roundsTillGhostSpawn, 0, 4) + 1).ToString();

        timeSinceLastRound += Time.deltaTime;
        if (!spawnedGhost && !TutorialScript.instance.img.activeSelf) {
            if (Input.GetKeyDown(KeyCode.A)) MoveBlocks(new Vector3Int(-1, 0, 0), tilemapBlocks, true);
            if (Input.GetKeyDown(KeyCode.D)) MoveBlocks(new Vector3Int(1, 0, 0), tilemapBlocks, true);
            if (Input.GetKeyDown(KeyCode.Q)) RotateBlock(1); // Rotate counterclockwise
            if (Input.GetKeyDown(KeyCode.E)) RotateBlock(-1);  // Rotate clockwise
        }
        else {
            if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.Q) || Input.GetKeyDown(KeyCode.E)) {
                CameraController.instance.Shake(0.05f, 0.05f);
                SoundManager.instance.effectSource.volume = 0.1f;
                SoundManager.instance.effectSource.clip = SoundManager.instance.errorEffect;
                SoundManager.instance.effectSource.Play();
                SoundManager.instance.effectSource.volume = 1f;
            }
        }
        if (Input.GetKey(KeyCode.S) && timeSinceLastRound > 0.3f && !placingGhost) {
            speed = superSpeed;
        }
        else {
            speed = normalSpeed;
        }
        if (placingGhost && !TutorialScript.instance.img.activeSelf) {
            if (Input.GetKeyDown(KeyCode.S)) {
                roundsTillGhostShow = -1;
                placingGhost = false;

                SoundManager.instance.effectSource.clip = SoundManager.instance.landEffect;
                SoundManager.instance.effectSource.Play();

                for (int x = -20; x < 20; x++) {
                    for (int y = -20; y < 20; y++) {
                        if (tilemapBlocks.GetTile(new Vector3Int(x, y))) {
                            ghostSnapshot[x + 20, y + 20] = true;
                            tilemapGhost.SetTile(new Vector3Int(x, y), ghostTile);
                        }
                        else {
                            ghostSnapshot[x + 20, y + 20] = false;
                        }
                    }
                }

                tilemapBlocks.ClearAllTiles();
                currentBlock = Random.Range(0, blockList.Count);
                SpawnBlock(blockList[currentBlock], 0);
                StartCoroutine(UpdateTilemap(blockList[currentBlock].type, speed));
            }
        }

        if (Input.GetKeyDown(KeyCode.G) && score >= 400 && !TutorialScript.instance.img.activeSelf && !placingGhost)
        {
            RevertTime();
            score -= 800;
        }

        //usuwanie rows
        for (int y = -20; y < 20; y++)
        {
            if (tilemapStaticBlocks.GetTilesRangeCount(new Vector3Int(-20, y), new Vector3Int(20, y)) >= 10)
            {
                DeleteRow(y, tilemapStaticBlocks);
                MoveBlocks(new Vector3Int(0, -1), tilemapStaticBlocks, false, y);
                score += 100;
                if (spawnedGhost) { 
                    score += 500;
                    if (volume.profile.TryGet<Bloom>(out bloom)) {
                        bloom.intensity.value = 200;
                    }
                }
            }
        }
    }

    public void SavePrefs(int hsc)
    {
        PlayerPrefs.SetInt("highScore", hsc);
        PlayerPrefs.Save();
    }

    public void LoadPrefs()
    {
        highScore = PlayerPrefs.GetInt("highScore", 0);
    }


    void TurnOffGhost()
    {
        spawnedGhost = false;
    }

    public void SpawnBlock(Block block, int xAxis) {
        if (roundsTillGhostShow == 0 && !placingGhost) {
            placingGhost = true;
            Invoke("TurnOffGhost", 0.1f);
            timeSinceBlockSpawn = 0;
            roundsTillGhostSpawn = 4;
            ghost = blockList[currentBlock];
            PlaceGhost(ghost, 0);
            return;
        }

        if (roundsTillGhostSpawn == 0) {
            SpawnGhost();
            spawnedGhost = true;
            roundsTillGhostShow = 0;
            return;
        }

        Invoke("TurnOffGhost", 0.1f);

        roundsTillGhostSpawn--;
        roundsTillGhostShow--;

        timeSinceLastRound = 0;
        pivotPoint = new Vector3Int(xAxis + 1, 12, 0); // Set pivot point (center of rotation)
        for (int i = 0; i < 4; i++) {
            if (block.one[i])
                tilemapBlocks.SetTile(new Vector3Int(xAxis, 12 + i), types[block.type]);
            if (block.two[i])
                tilemapBlocks.SetTile(new Vector3Int(xAxis + 1, 12 + i), types[block.type]);
            if (block.three[i])
                tilemapBlocks.SetTile(new Vector3Int(xAxis + 2, 12 + i), types[block.type]);
            if (block.four[i])
                tilemapBlocks.SetTile(new Vector3Int(xAxis + 3, 12 + i), types[block.type]);
        }
    }

    public void SpawnGhost() {
        tilemapGhost.ClearAllTiles();
        tilemapBlocks.ClearAllTiles();
        for (int x = 0; x < 40; x++) {
            for (int y = 0; y < 40; y++) {
                if (ghostSnapshot[x, y]) {
                    tilemapBlocks.SetTile(new Vector3Int(x - 20, y - 20), ghostTile);
                }
            }
        }
    }

    public void PlaceGhost(Block block, int xAxis) {
        if (playTutorial)   
        {
            if (firstGhost)
            {
                TutorialScript.instance.StartDialogue(2, 2);
            }
            firstGhost = false;
        }

        nextGhostText.gameObject.SetActive(true);

        pivotPoint = new Vector3Int(xAxis + 1, 11, 0); // Set pivot point (center of rotation)
        for (int i = 0; i < 4; i++) {
            if (block.one[i])
                tilemapBlocks.SetTile(new Vector3Int(xAxis, 11 + i), ghostTile);
            if (block.two[i])
                tilemapBlocks.SetTile(new Vector3Int(xAxis + 1, 11 + i), ghostTile);
            if (block.three[i])
                tilemapBlocks.SetTile(new Vector3Int(xAxis + 2, 11 + i), ghostTile);
            if (block.four[i])
                tilemapBlocks.SetTile(new Vector3Int(xAxis + 3, 11 + i), ghostTile);
        }
    }

    private Vector3Int CalculatePivotPoint(List<Vector3Int> positions) {
        int totalX = 0;
        int totalY = 0;

        foreach (var pos in positions) {
            totalX += pos.x;
            totalY += pos.y;
        }

        // Calculate the average position (center of mass)
        int centerX = Mathf.RoundToInt((float)totalX / positions.Count);
        int centerY = Mathf.RoundToInt((float)totalY / positions.Count);

        return new Vector3Int(centerX, centerY, 0);
    }


    public void RotateBlock(int direction) {
        // Get current block positions
        List<Vector3Int> currentPositions = GetCurrentBlockPositions(tilemapBlocks);

        // Calculate a dynamic pivot point
        pivotPoint = CalculatePivotPoint(currentPositions);

        List<Vector3Int> rotatedPositions = new List<Vector3Int>();

        foreach (var pos in currentPositions) {
            Vector3Int relativePosition = pos - pivotPoint;
            Vector3Int rotatedPosition;

            if (direction == 1) // Clockwise
            {
                rotatedPosition = new Vector3Int(-relativePosition.y, relativePosition.x, 0);
            }
            else // Counterclockwise
            {
                rotatedPosition = new Vector3Int(relativePosition.y, -relativePosition.x, 0);
            }

            rotatedPositions.Add(pivotPoint + rotatedPosition);
        }

        if (IsValidPosition(rotatedPositions)) {
            // Clear old positions
            foreach (var pos in currentPositions)
                tilemapBlocks.SetTile(pos, null);

            // Set new positions
            foreach (var pos in rotatedPositions) {
                if (placingGhost || spawnedGhost) {
                    tilemapBlocks.SetTile(pos, ghostTile);
                }
                else {
                    tilemapBlocks.SetTile(pos, types[blockList[currentBlock].type]);
                }
            }
        }
    }


    private List<Vector3Int> GetCurrentBlockPositions(Tilemap _tilemap) {
        List<Vector3Int> positions = new List<Vector3Int>();

        for (int x = -20; x < 20; x++) {
            for (int y = -20; y < 20; y++) {
                if (_tilemap.GetTile(new Vector3Int(x, y))) {
                    positions.Add(new Vector3Int(x, y, 0));
                }
            }
        }

        return positions;
    }

    private bool IsValidPosition(List<Vector3Int> positions) {
        foreach (var pos in positions) {
            // Check bounds and collisions
            if (tilemap.GetTile(pos) != null || tilemapStaticBlocks.GetTile(pos) != null || pos.x < -20 || pos.x > 20 || pos.y < -20) {
                return false;
            }
        }
        return true;
    }

    public void MoveBlocks(Vector3Int pos, Tilemap _tilemap, bool checkForCollision, int minY = -10) {
        Tile type = types[blockList[currentBlock].type];

        if (placingGhost || spawnedGhost) type = ghostTile;

        bool colliding = false;

        if (checkForCollision) {
            for (int x = -20; x < 20; x++) {
                for (int y = minY; y < 20; y++) {
                    if (_tilemap.GetTile(new Vector3Int(x, y))) {
                        if (tilemapStaticBlocks.GetTile(new Vector3Int(x, y) + pos) || tilemap.GetTile(new Vector3Int(x, y) + pos)) {
                            colliding = true;
                        }
                    }
                }
            }
        }

        if (!colliding) {
            if (pos.x < 0) {
                for (int x = -20; x < 20; x++) {
                    for (int y = minY; y < 20; y++) {
                        if (_tilemap.GetTile(new Vector3Int(x, y))) {
                            _tilemap.SetTile(new Vector3Int(x, y) + pos, _tilemap.GetTile(new Vector3Int(x, y)));
                            _tilemap.SetTile(new Vector3Int(x, y), null);
                        }
                    }
                }
            }
            else {
                for (int x = 20; x > -20; x--) {
                    for (int y = minY; y < 20; y++) {
                        if (_tilemap.GetTile(new Vector3Int(x, y))) {
                            _tilemap.SetTile(new Vector3Int(x, y) + pos, _tilemap.GetTile(new Vector3Int(x, y)));
                            _tilemap.SetTile(new Vector3Int(x, y), null);
                        }
                    }
                }
            }
        }
    }

    public void DeleteRow(int y, Tilemap tilemap) {
        for (int x = -5; x < 5; x++) {
            tilemap.SetTile(new Vector3Int(x, y), null);
        }

        SoundManager.instance.effectSource.clip = SoundManager.instance.DestroyEffect;
        SoundManager.instance.effectSource.Play();
        CameraController.instance.Shake(0.1f, 0.1f);
    }

    public void RevertTime()
    {
        for (int x = -5; x < 5; x++)
        {
            for (int y = -10; y < 10; y++)
            {
                if (beforeTab10[x + 5, y + 10])
                    tilemapStaticBlocks.SetTile(new Vector3Int(x, y), beforeTab10[x + 5, y + 10]); //fix colors
                else
                    tilemapStaticBlocks.SetTile(new Vector3Int(x, y), null);

            }

        }
    }
    private IEnumerator UpdateTilemap(int type2, float time) {
        Tile type = types[blockList[currentBlock].type];

        if (placingGhost || spawnedGhost) type = ghostTile;

        yield return new WaitForSeconds(1 / time);
        if (!placingGhost) {

            bool canMove = true;

            for (int x = -20; x < 20; x++)
            {
                for (int y = -20; y < 20; y++)
                {
                    if (tilemapBlocks.GetTile(new Vector3Int(x, y)))
                    {
                        if (tilemap.GetTile(new Vector3Int(x, y - 1)) || tilemapStaticBlocks.GetTile(new Vector3Int(x, y - 1)))
                        {
                            canMove = false;
                        }
                    }
                }
            }


            if (!canMove) {
                for (int i = -20; i < 20; i++) {
                    for (int j = -20; j < 20; j++) {

                        if (tilemapBlocks.GetTile(new Vector3Int(i, j))) {

                            //dying
                            if (j > 10)
                            {
                                if (score > highScore)
                                    highScore = score;
                                SavePrefs(highScore);
                                GameOverText.SetActive(true);
                                RestartButton.SetActive(true);
                                isDead = true;
                                Time.timeScale = 0;
                            }

                            tilemapStaticBlocks.SetTile(new Vector3Int(i, j), type);
                            tilemapBlocks.SetTile(new Vector3Int(i, j), null);
                        }
                    }
                }


                for (int y = -10; y < 10; y++)
                {
                    for (int x = -5; x < 5; x++)
                    {
                        beforeTab10[x + 5, y + 10] = beforeTab9[x + 5, y + 10];
                        beforeTab9[x + 5, y + 10] = beforeTab8[x + 5, y + 10];
                        beforeTab8[x + 5, y + 10] = beforeTab7[x + 5, y + 10];
                        beforeTab7[x + 5, y + 10] = beforeTab6[x + 5, y + 10];
                        beforeTab6[x + 5, y + 10] = beforeTab5[x + 5, y + 10];
                        beforeTab5[x + 5, y + 10] = beforeTab4[x + 5, y + 10];
                        beforeTab4[x + 5, y + 10] = beforeTab3[x + 5, y + 10];
                        beforeTab3[x + 5, y + 10] = beforeTab2[x + 5, y + 10];
                        beforeTab2[x + 5, y + 10] = beforeTab1[x + 5, y + 10];

                        beforeTab1[x + 5, y + 10] = tilemapStaticBlocks.GetTile<Tile>(new Vector3Int(x, y));
                    }
                }


                SoundManager.instance.effectSource.clip = SoundManager.instance.landEffect;

                if (speed == normalSpeed) {
                    SoundManager.instance.effectSource.volume = 0.6f;
                    CameraController.instance.Shake(0.05f, 0.05f);
                    SoundManager.instance.effectSource.Play();
                }
                else {
                    SoundManager.instance.effectSource.volume = 1f;
                    CameraController.instance.Shake(0.08f, 0.08f);
                    SoundManager.instance.effectSource.Play();
                }

                SoundManager.instance.effectSource.volume = 1f;

                turn++;

                currentBlock = Random.Range(0, blockList.Count);
                SpawnBlock(blockList[blockList[currentBlock].type], 0);
            }
            else {
                MoveBlocks(new Vector3Int(0, -1, 0), tilemapBlocks, false);
            }

            if (!placingGhost)
                StartCoroutine(UpdateTilemap(blockList[currentBlock].type, speed));
        }
    }
}

[System.Serializable]
public struct Block {
    public List<bool> one;
    public List<bool> two;
    public List<bool> three;
    public List<bool> four;

    public int type;
}
