using System.Collections;
using NUnit.Framework.Internal;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TutorialScript : MonoBehaviour
{
    public static TutorialScript instance { private set; get; }

    public Sprite[] panAdams;
    public Image panAdam;

    [TextArea(3, 10)]
    public string[] lines;

    bool finished = false;

    public TextMeshProUGUI text;

    int currentLetter;
    int currentLine;

    public GameObject img;

    int lastLine;
   

    public GameObject pressF;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Awake()
    {
        instance = this;
    }

    // Update is called once per frame
    void Update()
    {
        if (finished && Input.GetKeyDown(KeyCode.F)) {
            if (currentLine < lastLine) {
                PrintLine(currentLine);
            }
            else 
            {
                EndDialogue();
            }
        }

        if (finished) pressF.SetActive(true);
        else pressF.SetActive(false);
    }

    public void StartDialogue(int line, int amontOfLines) {
        img.SetActive(true);

        lastLine =  line + amontOfLines;
        Debug.Log("StartD");
        Time.timeScale = 0;
        PrintLine(line);
    }   

    void PrintLine(int line) {
        finished = false;

        text.text = " ";
        currentLetter = 0;
        StartCoroutine(PrintLetter(line, currentLetter));
    }

    IEnumerator PrintLetter(int line, int letter) {
        yield return new WaitForSecondsRealtime(0.05f);
        text.text += lines[line][letter];
        if (currentLetter % 3 == 0)
            panAdam.sprite = panAdams[Random.Range(0, panAdams.Length)];
        currentLetter++;

        if (currentLetter < lines[line].Length) {
            StartCoroutine(PrintLetter(line, currentLetter));
        }
        else {
            currentLine++;
            finished = true;
        }
    }

    void EndDialogue() {
        Time.timeScale = 1;
        text.text = " ";
        img.SetActive(false);
    }
}
