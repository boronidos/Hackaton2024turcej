using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class CameraController : MonoBehaviour {
    public static CameraController instance { get; private set; }

    private void Awake() {
        // If there is an instance, and it's not me, delete myself.

        if (instance != null && instance != this) {
            Destroy(this);
        }
        else {
            instance = this;
        }
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start() {

    }

    // Update is called once per frame
    void Update() {

    }

    public void Shake(float duration, float magnitude) {
        StartCoroutine(ShakeAction(duration, magnitude));
    }

    private IEnumerator ShakeAction(float duration, float magnitude) {

        float elapsed = 0.0f;
        Vector3 camPos = transform.position;

        while (elapsed < duration) {
            float x = Random.Range(-1f, 1f) * magnitude;
            float y = Random.Range(-1f, 1f) * magnitude;

            transform.localPosition += new Vector3(x, y, 0);

            elapsed += Time.unscaledDeltaTime;

            yield return null;
        }

        transform.position = new Vector3(-0.5f, 4, -10);
    }

}