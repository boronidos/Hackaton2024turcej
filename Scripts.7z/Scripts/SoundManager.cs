using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static SoundManager instance { private set; get; }

    public AudioClip mainMenuMusic;
    public AudioClip playMusic;

    public AudioClip landEffect;
    public AudioClip DestroyEffect;
    public AudioClip errorEffect;

    public AudioSource mainSource;
    public AudioSource effectSource;

    private void Awake() {
        instance = this;
        DontDestroyOnLoad(gameObject);
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
