using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuManager : MonoBehaviour
{
    public Animator anim;

    float animSpeed = 1;
    float _speed;

    public void Start() {
        SoundManager.instance.mainSource.clip = SoundManager.instance.mainMenuMusic;
        SoundManager.instance.mainSource.Play();
    }

    public void Update() {
        _speed = Mathf.Lerp(anim.GetFloat("Direction"), animSpeed, Time.deltaTime * 3);
        anim.SetFloat("Direction", _speed);
    }

    public void loadScene()
    {
        animSpeed = -2;
        StartCoroutine(Load());
    }

    private IEnumerator Load()
    {
        yield return new WaitForSeconds(1.5f);
        SceneManager.LoadScene("TestScene");
    }
}
